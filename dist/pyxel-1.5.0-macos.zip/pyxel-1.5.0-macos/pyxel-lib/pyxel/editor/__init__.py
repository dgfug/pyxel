from . import canvas_expansion  # noqa: F401
from .app import App


def edit_pyxel_resource_file(filename):
    App(filename)
